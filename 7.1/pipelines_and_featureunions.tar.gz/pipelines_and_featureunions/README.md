# Pipelines and Feature Unions

This is the code, data and presentation materials for a presentation on Pipelines and FeatureUnions given at Kaizen in September 2016.

# About me
Isaac Lemon Laughlin
Lead Instructor, Principal Data Scientist
[Galvanize Inc.](galvanize.com)

#Get started!

[Please refer to the notebook for more](pipelines_and_featureunions.ipynb)
